export type Rarity = "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary" | "Mythic";

export function calculateRarity(unitsProduced?: number | null, specialEdition?: boolean): Rarity {
  if (specialEdition && unitsProduced != null && unitsProduced <= 50) return "Mythic";
  if (unitsProduced != null && unitsProduced <= 250) return "Legendary";
  if (specialEdition && unitsProduced != null && unitsProduced <= 1000) return "Epic";
  if (unitsProduced != null && unitsProduced <= 5000) return "Rare";
  if (specialEdition || (unitsProduced != null && unitsProduced <= 25000)) return "Uncommon";
  return "Common";
}
