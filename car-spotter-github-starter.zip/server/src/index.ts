import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import OpenAI from "openai";
import { calculateRarity } from "./rarity.js";

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
const port = Number(process.env.PORT || 8787);

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not set. /identify will fail until it is configured.");
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    make: { type: "string" },
    model: { type: "string" },
    year: { type: ["integer", "null"] },
    trim: { type: ["string", "null"] },
    engine: { type: ["string", "null"] },
    horsepower: { type: ["number", "null"] },
    torqueLbFt: { type: ["number", "null"] },
    zeroTo60Sec: { type: ["number", "null"] },
    curbWeightLb: { type: ["number", "null"] },
    driveType: { type: ["string", "null"] },
    topSpeedMph: { type: ["number", "null"] },
    unitsProduced: { type: ["integer", "null"] },
    bodyStyle: { type: ["string", "null"] },
    transmission: { type: ["string", "null"] },
    specialEdition: { type: "boolean" }
  },
  required: [
    "make", "model", "year", "trim", "engine", "horsepower", "torqueLbFt",
    "zeroTo60Sec", "curbWeightLb", "driveType", "topSpeedMph", "unitsProduced",
    "bodyStyle", "transmission", "specialEdition"
  ]
};

app.use(cors());

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/identify", upload.single("photo"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "photo is required" });

    const mime = req.file.mimetype || "image/jpeg";
    const base64 = req.file.buffer.toString("base64");

    const response = await openai.responses.create({
      model: "gpt-5.6-luna",
      input: [{
        role: "user",
        content: [
          {
            type: "input_text",
            text:
              "Identify the vehicle in this image for a car-spotting collectible card. " +
              "Return only the requested structured fields. If the exact year, trim, or specification " +
              "cannot be established from the image, return null rather than inventing it. " +
              "Use numeric values in US units. Production count may be null when unknown. " +
              "specialEdition should only be true when the image or known model identity supports that conclusion."
          },
          {
            type: "input_image",
            image_url: `data:${mime};base64,${base64}`
          }
        ]
      }],
      text: {
        format: {
          type: "json_schema",
          name: "car_identification",
          strict: true,
          schema
        }
      }
    });

    const car = JSON.parse(response.output_text);
    const rarity = calculateRarity(car.unitsProduced, car.specialEdition);

    res.json({
      ...car,
      rarity
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Vehicle identification failed." });
  }
});

app.listen(port, () => {
  console.log(`Car Spotter server running on http://localhost:${port}`);
});
