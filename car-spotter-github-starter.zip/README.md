# Car Spotter

A focused car-spotting collectible-card app.

## Product rules (intentionally strict)

1. The Scan screen only offers **Take Photo** and **Choose From Camera Roll**.
2. A submitted image is scanned by AI.
3. The result becomes a collectible trading card.
4. Card front: submitted photo, car name, rarity/color, and basic specs.
5. Card back: detailed specs.
6. Cards are saved to the Garage.
7. Garage can filter by rarity and brand.
8. Cards can be flipped in the Garage.
9. No social feed, map, leaderboard, chat, marketplace, profiles, or other features are included.

## Architecture

- `mobile/`: Expo + React Native + TypeScript iOS/Android app.
- `server/`: small Node/Express API. The OpenAI API key stays on the server and is never shipped in the app.
- The first version stores the Garage locally with AsyncStorage. This keeps the MVP simple and avoids accounts/backend database work.
- The server accepts a photo and returns structured vehicle identification/spec data.
- Rarity is computed by deterministic rules in `server/src/rarity.ts`, rather than letting the model arbitrarily choose a color.

## 1. Run the server

```bash
cd server
npm install
cp .env.example .env
# Put your OPENAI_API_KEY in .env
npm run dev
```

The server listens on `http://localhost:8787`.

For a physical phone, `localhost` means the phone itself. Set `EXPO_PUBLIC_API_URL` to your computer's LAN IP, e.g. `http://192.168.1.25:8787`.

## 2. Run the mobile app

```bash
cd mobile
npm install
cp .env.example .env
# Set EXPO_PUBLIC_API_URL
npx expo start
```

Use Expo Go for the quickest prototype. For a production iOS build, use an Expo development build / EAS Build.

## Important

The current AI endpoint is a real integration, but vehicle specifications returned by a general vision model should be treated as a first-pass identification layer. Before launch, connect the identified make/model/year to a verified automotive data source and use that source for exact specifications and production counts.

Do not put `OPENAI_API_KEY` in the mobile app or GitHub.
