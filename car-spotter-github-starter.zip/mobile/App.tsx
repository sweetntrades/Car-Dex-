import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Animated,
  Easing,
  FlatList,
  Image,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StatusBar } from "expo-status-bar";

const API_URL = process.env.EXPO_PUBLIC_API_URL || "http://localhost:8787";
const GARAGE_KEY = "car-spotter-garage-v1";

type Rarity = "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary" | "Mythic";

type Car = {
  id: string;
  imageUri: string;
  make: string;
  model: string;
  year?: number | null;
  trim?: string | null;
  rarity: Rarity;
  rarityColor: string;
  engine?: string | null;
  horsepower?: number | null;
  torqueLbFt?: number | null;
  zeroTo60Sec?: number | null;
  curbWeightLb?: number | null;
  driveType?: string | null;
  topSpeedMph?: number | null;
  unitsProduced?: number | null;
  bodyStyle?: string | null;
  transmission?: string | null;
  scannedAt: string;
};

const RARITIES: Rarity[] = ["Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic"];

const rarityColor: Record<Rarity, string> = {
  Common: "#777E87",
  Uncommon: "#38A169",
  Rare: "#3182CE",
  Epic: "#805AD5",
  Legendary: "#D69E2E",
  Mythic: "#E53E3E",
};

function display(value: unknown, suffix = "") {
  return value === null || value === undefined || value === "" ? "—" : `${value}${suffix}`;
}

function App() {
  const [screen, setScreen] = useState<"scan" | "garage">("scan");
  const [phase, setPhase] = useState<"idle" | "scanning" | "card">("idle");
  const [current, setCurrent] = useState<Car | null>(null);
  const [garage, setGarage] = useState<Car[]>([]);
  const [filter, setFilter] = useState<string>("All");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(GARAGE_KEY).then((raw) => {
      if (raw) setGarage(JSON.parse(raw));
    });
  }, []);

  async function persist(next: Car[]) {
    setGarage(next);
    await AsyncStorage.setItem(GARAGE_KEY, JSON.stringify(next));
  }

  async function chooseImage(useCamera: boolean) {
    setError(null);
    try {
      const result = useCamera
        ? await ImagePicker.launchCameraAsync({
            mediaTypes: ["images"],
            quality: 0.9,
            allowsEditing: false,
          })
        : await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ["images"],
            quality: 0.9,
            allowsEditing: false,
            selectionLimit: 1,
          });

      if (result.canceled || !result.assets?.[0]?.uri) return;
      await scan(result.assets[0].uri);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not open the image.");
    }
  }

  async function scan(uri: string) {
    setPhase("scanning");
    setScreen("scan");
    try {
      const form = new FormData();
      form.append("photo", {
        uri,
        name: "car.jpg",
        type: "image/jpeg",
      } as any);

      const response = await fetch(`${API_URL}/identify`, {
        method: "POST",
        body: form,
      });

      if (!response.ok) {
        const body = await response.text();
        throw new Error(body || `Server error ${response.status}`);
      }

      const result = await response.json();
      const car: Car = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        imageUri: uri,
        ...result,
        rarityColor: rarityColor[result.rarity as Rarity] || rarityColor.Common,
        scannedAt: new Date().toISOString(),
      };

      setCurrent(car);
      setPhase("card");
    } catch (e) {
      setPhase("idle");
      setError(e instanceof Error ? e.message : "The scan failed.");
      Alert.alert("Scan failed", "We couldn't identify that car. Please try another photo.");
    }
  }

  async function addCurrent() {
    if (!current) return;
    const next = [current, ...garage];
    await persist(next);
    setScreen("garage");
    setPhase("idle");
  }

  const filtered = useMemo(() => {
    if (filter === "All") return garage;
    if (RARITIES.includes(filter as Rarity)) return garage.filter((c) => c.rarity === filter);
    return garage.filter((c) => c.make.toLowerCase() === filter.toLowerCase());
  }, [garage, filter]);

  const brands = Array.from(new Set(garage.map((c) => c.make))).sort();

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.logo}>CAR<Text style={styles.logoAccent}>SPOTTER</Text></Text>
        <Text style={styles.count}>{garage.length} {garage.length === 1 ? "card" : "cards"}</Text>
      </View>

      {screen === "scan" && (
        <ScanScreen
          phase={phase}
          error={error}
          onCamera={() => chooseImage(true)}
          onRoll={() => chooseImage(false)}
          current={current}
          onAdd={addCurrent}
        />
      )}

      {screen === "garage" && (
        <GarageScreen
          cars={filtered}
          filters={["All", ...RARITIES, ...brands]}
          active={filter}
          onFilter={setFilter}
          onOpen={(car) => {
            setCurrent(car);
            setPhase("card");
            setScreen("scan");
          }}
        />
      )}

      <View style={styles.nav}>
        <NavButton label="SCAN" active={screen === "scan"} onPress={() => { setScreen("scan"); setPhase("idle"); }} icon="＋" />
        <NavButton label="GARAGE" active={screen === "garage"} onPress={() => setScreen("garage")} icon="▦" />
      </View>
    </SafeAreaView>
  );
}

function ScanScreen({
  phase, error, onCamera, onRoll, current, onAdd,
}: {
  phase: "idle" | "scanning" | "card";
  error: string | null;
  onCamera: () => void;
  onRoll: () => void;
  current: Car | null;
  onAdd: () => void;
}) {
  if (phase === "scanning") {
    return <Scanning />;
  }

  if (phase === "card" && current) {
    return <CardResult car={current} onAdd={onAdd} />;
  }

  return (
    <View style={styles.centerPage}>
      <View style={styles.hero}>
        <Text style={styles.heroTitle}>Spot it.{"\n"}Scan it.{"\n"}Collect it.</Text>
        <Text style={styles.heroCopy}>
          Photograph a car you find and turn it into a collectible card.
        </Text>
      </View>
      <Pressable style={[styles.action, styles.primary]} onPress={onCamera}>
        <Text style={styles.primaryText}>📷  Take Photo</Text>
      </Pressable>
      <Pressable style={styles.action} onPress={onRoll}>
        <Text style={styles.actionText}>🖼  Choose From Camera Roll</Text>
      </Pressable>
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
}

function Scanning() {
  const y = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(y, { toValue: 1, duration: 1200, easing: Easing.inOut(Easing.linear), useNativeDriver: true }),
        Animated.timing(y, { toValue: 0, duration: 1200, easing: Easing.inOut(Easing.linear), useNativeDriver: true }),
      ])
    ).start();
  }, [y]);

  return (
    <View style={styles.scanPage}>
      <View style={styles.scanCircle}>
        <Animated.View style={[styles.scanLine, { transform: [{ translateY: y.interpolate({ inputRange: [0, 1], outputRange: [-72, 72] }) }] }]} />
      </View>
      <ActivityIndicator size="small" color="#D9FF4F" />
      <Text style={styles.scanTitle}>IDENTIFYING VEHICLE</Text>
      <Text style={styles.scanCopy}>Analyzing image and matching the vehicle...</Text>
    </View>
  );
}

function CardResult({ car, onAdd }: { car: Car; onAdd: () => void }) {
  const [flipped, setFlipped] = useState(false);
  const spin = useRef(new Animated.Value(0)).current;
  const frontRotate = spin.interpolate({ inputRange: [0, 1], outputRange: ["0deg", "180deg"] });
  const backRotate = spin.interpolate({ inputRange: [0, 1], outputRange: ["180deg", "360deg"] });

  function flip() {
    Animated.spring(spin, { toValue: flipped ? 0 : 1, useNativeDriver: true, friction: 8 }).start();
    setFlipped(!flipped);
  }

  return (
    <View style={styles.resultPage}>
      <Pressable onPress={flip} style={styles.cardPerspective}>
        <View style={[styles.cardFace, { borderColor: car.rarityColor, transform: [{ rotateY: frontRotate }] }]}>
          <Image source={{ uri: car.imageUri }} style={styles.cardImage} resizeMode="cover" />
          <View style={styles.cardInfo}>
            <Text style={[styles.rarity, { color: car.rarityColor }]}>{car.rarity}</Text>
            <Text style={styles.cardName}>{car.make} {car.model}</Text>
            <View style={styles.specGrid}>
              <Spec label="POWER" value={display(car.horsepower, " HP")} />
              <Spec label="ENGINE" value={car.engine || "—"} />
              <Spec label="0–60" value={display(car.zeroTo60Sec, " sec")} />
              <Spec label="DRIVE" value={car.driveType || "—"} />
            </View>
          </View>
        </View>

        <View style={[styles.cardFace, styles.cardBack, { borderColor: car.rarityColor, transform: [{ rotateY: backRotate }] }]}>
          <Text style={styles.backTitle}>{car.make} {car.model}</Text>
          <Text style={[styles.rarity, { color: car.rarityColor }]}>{car.year || ""} • {car.rarity}</Text>
          <View style={styles.detailGrid}>
            <Spec label="ENGINE" value={car.engine || "—"} />
            <Spec label="POWER" value={display(car.horsepower, " HP")} />
            <Spec label="TORQUE" value={display(car.torqueLbFt, " lb-ft")} />
            <Spec label="0–60 MPH" value={display(car.zeroTo60Sec, " sec")} />
            <Spec label="CURB WEIGHT" value={display(car.curbWeightLb, " lb")} />
            <Spec label="DRIVE TYPE" value={car.driveType || "—"} />
            <Spec label="TOP SPEED" value={display(car.topSpeedMph, " MPH")} />
            <Spec label="UNITS PRODUCED" value={car.unitsProduced?.toLocaleString() || "—"} />
            <Spec label="TRANSMISSION" value={car.transmission || "—"} />
            <Spec label="BODY STYLE" value={car.bodyStyle || "—"} />
          </View>
        </View>
      </Pressable>
      <Text style={styles.flipHint}>Tap the card to flip</Text>
      <Pressable style={[styles.action, styles.primary]} onPress={onAdd}>
        <Text style={styles.primaryText}>Add to Garage</Text>
      </Pressable>
    </View>
  );
}

function Spec({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.spec}>
      <Text style={styles.specLabel}>{label}</Text>
      <Text style={styles.specValue} numberOfLines={2}>{value}</Text>
    </View>
  );
}

function GarageScreen({
  cars, filters, active, onFilter, onOpen,
}: {
  cars: Car[];
  filters: string[];
  active: string;
  onFilter: (v: string) => void;
  onOpen: (c: Car) => void;
}) {
  return (
    <View style={styles.garagePage}>
      <Text style={styles.garageTitle}>Garage</Text>
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={filters}
        keyExtractor={(x) => x}
        contentContainerStyle={styles.filters}
        renderItem={({ item }) => (
          <Pressable style={[styles.filter, active === item && styles.filterActive]} onPress={() => onFilter(item)}>
            <Text style={[styles.filterText, active === item && styles.filterTextActive]}>{item}</Text>
          </Pressable>
        )}
      />
      <FlatList
        data={cars}
        numColumns={2}
        keyExtractor={(item) => item.id}
        columnWrapperStyle={{ gap: 12 }}
        contentContainerStyle={{ gap: 12, paddingBottom: 110 }}
        ListEmptyComponent={<Text style={styles.empty}>No cards yet. Go spot a car.</Text>}
        renderItem={({ item }) => (
          <Pressable style={styles.miniCard} onPress={() => onOpen(item)}>
            <Image source={{ uri: item.imageUri }} style={styles.miniImage} />
            <Text style={styles.miniName} numberOfLines={1}>{item.make} {item.model}</Text>
            <Text style={[styles.miniRarity, { color: item.rarityColor }]}>{item.rarity}</Text>
          </Pressable>
        )}
      />
    </View>
  );
}

function NavButton({ label, active, onPress, icon }: { label: string; active: boolean; onPress: () => void; icon: string }) {
  return (
    <Pressable style={styles.navButton} onPress={onPress}>
      <Text style={[styles.navIcon, active && styles.navActive]}>{icon}</Text>
      <Text style={[styles.navLabel, active && styles.navActive]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#090B0E" },
  header: { height: 64, paddingHorizontal: 20, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  logo: { color: "#F5F7FA", fontSize: 17, fontWeight: "900", letterSpacing: -0.4 },
  logoAccent: { color: "#D9FF4F" },
  count: { color: "#8F969F", fontSize: 12, fontWeight: "700" },
  centerPage: { flex: 1, padding: 20, justifyContent: "center", gap: 12 },
  hero: { marginBottom: 26 },
  heroTitle: { color: "#F5F7FA", fontSize: 46, lineHeight: 44, fontWeight: "900", letterSpacing: -2.5 },
  heroCopy: { color: "#8F969F", fontSize: 16, lineHeight: 24, marginTop: 16, maxWidth: 330 },
  action: { height: 58, borderRadius: 18, borderWidth: 1, borderColor: "#292E36", backgroundColor: "#12151A", alignItems: "center", justifyContent: "center" },
  primary: { backgroundColor: "#D9FF4F", borderColor: "#D9FF4F" },
  primaryText: { color: "#080A0C", fontWeight: "900", fontSize: 16 },
  actionText: { color: "#F5F7FA", fontWeight: "800", fontSize: 16 },
  error: { color: "#FCA5A5", textAlign: "center", marginTop: 8 },
  nav: { position: "absolute", bottom: 0, left: 0, right: 0, height: 78, backgroundColor: "#0D1014", borderTopWidth: 1, borderTopColor: "#252A31", flexDirection: "row" },
  navButton: { flex: 1, alignItems: "center", justifyContent: "center" },
  navIcon: { color: "#737A84", fontSize: 22, lineHeight: 24 },
  navLabel: { color: "#737A84", fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  navActive: { color: "#F5F7FA" },
  scanPage: { flex: 1, alignItems: "center", justifyContent: "center", gap: 14, paddingBottom: 70 },
  scanCircle: { width: 190, height: 190, borderRadius: 95, borderWidth: 1, borderColor: "#303740", overflow: "hidden", justifyContent: "center" },
  scanLine: { height: 2, backgroundColor: "#D9FF4F", shadowColor: "#D9FF4F", shadowOpacity: 1, shadowRadius: 10, elevation: 4 },
  scanTitle: { color: "#F5F7FA", fontWeight: "900", fontSize: 18, marginTop: 8 },
  scanCopy: { color: "#8F969F", fontSize: 14 },
  resultPage: { flex: 1, padding: 20, alignItems: "center", paddingBottom: 90 },
  cardPerspective: { width: "100%", maxWidth: 350, height: 500, marginTop: 12 },
  cardFace: { position: "absolute", width: "100%", height: "100%", backgroundColor: "#171A20", borderWidth: 2, borderRadius: 25, overflow: "hidden", backfaceVisibility: "hidden" },
  cardImage: { width: "100%", height: "57%" },
  cardInfo: { padding: 16 },
  rarity: { textTransform: "uppercase", fontSize: 11, fontWeight: "900", letterSpacing: 1.5 },
  cardName: { color: "#F5F7FA", fontSize: 25, fontWeight: "900", marginTop: 4 },
  specGrid: { flexDirection: "row", flexWrap: "wrap", gap: 14, marginTop: 15 },
  spec: { width: "46%" },
  specLabel: { color: "#7F8791", fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  specValue: { color: "#F5F7FA", fontSize: 14, fontWeight: "800", marginTop: 3 },
  cardBack: { padding: 20, transform: [{ rotateY: "180deg" }] },
  backTitle: { color: "#F5F7FA", fontSize: 25, fontWeight: "900" },
  detailGrid: { flexDirection: "row", flexWrap: "wrap", gap: 15, marginTop: 22 },
  flipHint: { color: "#7F8791", marginVertical: 12, fontSize: 12 },
  garagePage: { flex: 1, paddingHorizontal: 20 },
  garageTitle: { color: "#F5F7FA", fontSize: 34, fontWeight: "900", marginBottom: 8 },
  filters: { gap: 8, paddingVertical: 10 },
  filter: { borderWidth: 1, borderColor: "#292E36", borderRadius: 999, paddingHorizontal: 13, paddingVertical: 9, backgroundColor: "#12151A" },
  filterActive: { backgroundColor: "#F5F7FA", borderColor: "#F5F7FA" },
  filterText: { color: "#A1A8B1", fontSize: 12, fontWeight: "800" },
  filterTextActive: { color: "#0A0C0F" },
  miniCard: { width: "48%", backgroundColor: "#14171C", borderRadius: 18, padding: 9 },
  miniImage: { width: "100%", aspectRatio: .75, borderRadius: 12, backgroundColor: "#252A31" },
  miniName: { color: "#F5F7FA", fontSize: 14, fontWeight: "900", marginTop: 8 },
  miniRarity: { fontSize: 10, fontWeight: "900", textTransform: "uppercase", letterSpacing: 1, marginTop: 3 },
  empty: { color: "#7F8791", textAlign: "center", width: "100%", marginTop: 50 },
});

export default App;
